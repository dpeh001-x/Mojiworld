# LevelX — Shardfall Expedition (export bundle)

Single-file 2D action-platformer RPG. Entire game lives in `maple_game.html`
(~28k lines vanilla JS, no build step).

## How to run

1. From this directory: `python -m http.server 8765`
2. Open http://localhost:8765/maple_game.html
3. Or just open `maple_game.html` directly in a browser via `file://`

## Top-level layout

```
maple_game.html              ← THE GAME (canvas + HUD + systems + logic)
sprite_maker.html            ← sprite preview / dev tool
sprite_preview.html          ← another sprite dev tool
CHANGELOG.html               ← shipping log (newest on top within each section)
MOBILE_CHANGELOG.html        ← mobile-branch-only release notes
GAMING_AUDIT.html            ← gameplay audit notes
MOBILE_GAMEPLAY_AUDIT.html   ← mobile-specific audit
README.md, SETUP.md          ← project intro + setup
CLAUDE.md                    ← project conventions for Claude Code
.gitignore                   ← repo gitignores (.mcp.json, backgrounds/, etc.)
.mcp.json                    ← Claude Code MCP server config (ludo.ai)
                              ⚠ API key SANITIZED in this export — replace
                              `REPLACE_WITH_YOUR_LUDO_API_KEY` with your own.
```

## Sprites/character (layered avatar system, v0.25.72–v0.25.76)

```
Sprites/character/
├── extract_layer.py         ← generic pixel-diff layer extractor (soft-alpha)
├── extract_face.py          ← face-specific extractor (eye outline + opaque pupils)
├── neutralize_skin.py       ← coloured mannequin → grayscale luminance for runtime tinting
├── preview_compose.py       ← stack layers offline for visual verification
├── preview_skin_tone.py     ← mimic the runtime canvas multiply for offline preview
└── layers/
    ├── base/
    │   ├── mannequin_base.webp           ← canonical (peach default, transparent bg)
    │   └── mannequin_base_neutral.webp   ← grayscale tinting target (runtime)
    ├── eyes/
    │   ├── anime_classic.webp   ← classic chibi eyes + gentle smile
    │   ├── sleepy_calm.webp     ← closed-eyelid arches
    │   ├── sharp_serious.webp   ← angular angry/serious + scowl
    │   └── big_grin.webp        ← oversized sparkle eyes + open grin
    └── hair/
        ├── blonde_shaggy.webp
        ├── black_spike.webp
        ├── brown_pony.webp
        └── mage_hood.webp
```

## Sprites/ (asset generation prompts + tools)

Various `*.md` sprite prompts and `gen_*.py` Python generation scripts.
The actual generated 1024×1024 sprites live alongside but are too large
for this code-focused export.

## .claude/

Claude Code project config:
- `.claude/hooks/session-start.sh` — auto-fetch + rebase on session open
- `.claude/hooks/mobile-pre-push.py` — gates pushes against the mobile branch
- `.claude/hooks/mobile-zone-check.py` — warns about edits outside mobile safe zones
- `.claude/settings.json` — versioned permissions (committed)
- `.claude/launch.json` — Claude Preview server config

## NOT included in this export

- `.git/` — version history
- `backgrounds/` — 56MB of background images (not relevant for code review)
- `Sprites/character/layers/eyes/_*.webp` — source composites kept locally
  for re-extraction tuning (large files, not used at runtime)
- `Sprites/character/layers/hair/_*.webp` — same

## The Character Studio (recent feature, v0.25.72–v0.25.76)

Press **Q** in-game to open the studio:
- 6 skin tones (Porcelain → Deep) tinted via per-pixel canvas multiply
- 4 face styles + 5 hair styles (incl. Bald)
- ▶ "Use in game" button to apply the composite to the live player sprite
- ↺ "Revert" to restore procedural drawing

Architecture: ludo.ai generates "mannequin + feature" composites →
`extract_layer.py` / `extract_face.py` produce transparent-background
feature-only layer PNGs → runtime `renderCharStudio()` stacks them on a
neutralised grayscale base, then per-pixel multiplies the chosen skin tone.

## Recent shipping log (v0.25.x highlights — see CHANGELOG.html for full)

| Version | Title |
|---|---|
| v0.25.76 | Hair z-order fix — bangs occlude eyes (chibi convention) |
| v0.25.75 + b/c | Apply studio avatar to live in-game player + coord fix + layout fix |
| v0.25.74 | Hair slot + soft-alpha extraction (4 hair styles) |
| v0.25.73 | 4 face styles + face-aware extractor + halo fixes |
| v0.25.72 | Layered avatar system — ludo.ai sprite pipeline + Character Studio (Q) |
| v0.25.67 | Curved-path stylish hair (procedural — superseded by v0.25.72) |
| v0.25.63 | Distinct biome layouts + low-grav Stardust Atrium |
| v0.25.61 | Quest system — kill / visit / boss with rewards (J) |
